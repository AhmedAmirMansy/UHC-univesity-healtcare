package com.example.uhc_universityhealthcare

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import android.view.View
import com.google.firebase.auth.EmailAuthProvider


class ProfileActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    // UI elements
    private lateinit var emailTextView: EditText
    private lateinit var firstNameEditText: EditText
    private lateinit var lastNameEditText: EditText
    private lateinit var ageEditText: EditText
    private lateinit var editButton: Button
    private lateinit var saveButton: Button

    private var isEditing: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Initialize Firebase Auth and Firestore
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Initialize views
        emailTextView = findViewById(R.id.tv_email)
        firstNameEditText = findViewById(R.id.et_first_name)
        lastNameEditText = findViewById(R.id.et_last_name)
        ageEditText = findViewById(R.id.et_age)
        editButton = findViewById(R.id.btn_edit_profile)
        saveButton = findViewById(R.id.btn_save_profile)

        // Initially disable text fields
        setFieldsEnabled(false)

        // Load the user's data
        loadUserData()

        // Edit button listener
        editButton.setOnClickListener {
            isEditing = true
            setFieldsEnabled(true)  // Enable text fields
            saveButton.visibility = View.VISIBLE  // Show the save button
        }

        // Save button listener
        saveButton.setOnClickListener {
            if (isEditing) {
                saveProfileData()
                setFieldsEnabled(false)  // Disable text fields
                saveButton.visibility = View.GONE  // Hide the save button
                isEditing = false
            }
        }
    }

    private fun setFieldsEnabled(enabled: Boolean) {
        emailTextView.isEnabled = enabled
        firstNameEditText.isEnabled = enabled
        lastNameEditText.isEnabled = enabled
        ageEditText.isEnabled = enabled
    }

    private fun loadUserData() {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // Set the email in the text field
            emailTextView.setText(currentUser.email)

            // Fetch additional user data from Firestore
            firestore.collection("users").document(currentUser.uid).get()
                .addOnSuccessListener { document ->
                    if (document != null) {
                        firstNameEditText.setText(document.getString("firstName"))
                        lastNameEditText.setText(document.getString("lastName"))
                        ageEditText.setText(document.getLong("age")?.toString())
                    }
                }
        }
    }

    private fun saveProfileData() {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // Prompt the user to enter their password
            val userPassword = "user_input_password" // Get this from user input (e.g., from an EditText)

            // Use EmailAuthProvider to create credentials
            val credential = EmailAuthProvider.getCredential(currentUser.email!!, userPassword)

            // Re-authenticate the user
            currentUser.reauthenticate(credential).addOnCompleteListener { reAuthTask ->
                if (reAuthTask.isSuccessful) {
                    // Re-authentication was successful. Now update the email
                    val newEmail = emailTextView.text.toString()
                    currentUser.updateEmail(newEmail).addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(this, "Email updated successfully!", Toast.LENGTH_SHORT).show()
                            Log.d("ProfileActivity", "User email address updated.")
                        } else {
                            Toast.makeText(this, "Failed to update email.", Toast.LENGTH_SHORT).show()
                            Log.e("ProfileActivity", "Error updating email", task.exception)
                        }
                    }
                } else {
                    // Handle failure in re-authentication
                    Toast.makeText(this, "Re-authentication failed.", Toast.LENGTH_SHORT).show()
                    Log.e("ProfileActivity", "Re-authentication failed", reAuthTask.exception)
                }
            }

            // Save additional user information in Firestore
            val userData = hashMapOf(
                "firstName" to firstNameEditText.text.toString(),
                "lastName" to lastNameEditText.text.toString(),
                "age" to ageEditText.text.toString().toIntOrNull()
            )

            firestore.collection("users").document(currentUser.uid).set(userData)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
                        Log.d("ProfileActivity", "User profile updated in Firestore.")
                    } else {
                        Toast.makeText(this, "Failed to update profile.", Toast.LENGTH_SHORT).show()
                        Log.e("ProfileActivity", "Error updating profile", task.exception)
                    }
                }
        }
    }
}